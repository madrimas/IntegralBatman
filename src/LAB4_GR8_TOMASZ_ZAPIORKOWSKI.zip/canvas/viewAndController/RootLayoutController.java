package canvas.viewAndController;

import canvas.Main;

/**
 * Created by madrimas on 02.04.2017.
 */
public class RootLayoutController {
    private Main main;

    public void setMain(Main main){
        this.main = main;
    }


}
